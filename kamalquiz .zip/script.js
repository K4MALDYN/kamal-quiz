const form = document.getElementById("registerForm");
const container = document.querySelector(".container");
if (localStorage.getItem("played")) {
  alert("Already played!");
  location.href = "https://google.com";
}
const correctSound = new Audio("correct.mp3");
const wrongSound = new Audio("wrong.mp3");

const questions = [
  { question: "Which company created Free Fire?", answers: ["Tencent", "Garena", "Epic Games"], correct: 1 },
  { question: "What is the maximum level of an Evo Gun?", answers: ["5", "7", "9"], correct: 1 },
  { question: "Which map is the largest?", answers: ["Bermuda", "Alpine", "Kalahari"], correct: 1 },
  { question: "What is the maximum sensitivity in Free Fire?", answers: ["100", "150", "200"], correct: 2 },
  { question: "Which gun is known for one-tap headshots?", answers: ["Desert Eagle", "UMP", "MP40"], correct: 0 },
  
  { question: "How many players start in a Free Fire match?", answers: ["50", "100", "120"], correct: 0 },
  { question: "What is Free Fire currency called?", answers: ["gold", "Diamonds", "Tokens"], correct: 1 },
  { question: "Which mode is Clash Squad?", answers: ["Battle Royale", "Team vs Team", "Story Mode"], correct: 1 },
  { question: "Which character can heal teammates?", answers: ["Alok", "Kelly", "Hayato"], correct: 0 },
  { question: "Which gun is an SMG?", answers: ["AWM", "MP40", "M1014"], correct: 1 },
  
  { question: "Which is a sniper rifle?", answers: ["UMP", "AWM", "MP5"], correct: 1 },
  { question: "What does HP mean?", answers: ["Health Points", "Hit Power", "High Power"], correct: 0 },
  { question: "Which pet is in Free Fire?", answers: ["Dreki", "Pikachu", "Tom"], correct: 0 },
  { question: "Which attachment reduces recoil?", answers: ["Silencer", "Foregrip", "Scope"], correct: 1 },
  { question: "Which gun uses shotgun ammo?", answers: ["M1014", "AK47", "MP40"], correct: 0 },
  
  { question: "Which map has a desert theme?", answers: ["Kalahari", "Bermuda", "Purgatory"], correct: 0 },
  { question: "Which gun has high fire rate?", answers: ["MP40", "AWM", "Woodpecker"], correct: 0 },
  { question: "What does FF stand for?", answers: ["Fast Fight", "Free Fire", "Final Fight"], correct: 1 },
  { question: "Which item helps revive teammates faster?", answers: ["Medkit", "Gloo Wall", "Helmet"], correct: 0 },
  { question: "Which weapon is best for close range?", answers: ["Shotgun", "Sniper", "Marksman"], correct: 0 },
  
  { question: "Which map has Peak in the center?", answers: ["Bermuda", "Kalahari", "Alpine"], correct: 0 },
  { question: "Which gun is AK47?", answers: ["Assault Rifle", "Sniper", "SMG"], correct: 0 },
  { question: "Which character ability increases speed?", answers: ["Kelly", "Moco", "A124"], correct: 0 },
  { question: "What is Gloo Wall used for?", answers: ["Defense", "Healing", "Speed boost"], correct: 0 },
  { question: "Which is a throwable item?", answers: ["Grenade", "AWM", "Helmet"], correct: 0 },
  
  { question: "Which gun is good for mid range?", answers: ["SCAR", "M1014", "MP40"], correct: 0 },
  { question: "What is headshot multiplier?", answers: ["More damage", "Less damage", "No damage"], correct: 0 },
  { question: "Which map is snow themed?", answers: ["Alpine", "Bermuda", "Kalahari"], correct: 0 },
  { question: "Which gun has highest damage per shot?", answers: ["AWM", "MP40", "UMP"], correct: 0 },
  { question: "Which mode gives ranked points?", answers: ["Ranked Mode", "Training", "Custom Room"], correct: 0 }
];

let currentQuestion = 0;
let score = 0;
let streak = 0;
let playerName = "";
let timer;
let timeLeft = 10;
let canClick = true;

const highScoreKey = "kamalQuizHighScore";

// START GAME
form.addEventListener("submit", (e) => {
  e.preventDefault();
  
  playerName = document.getElementById("name").value.trim();
  
  if (!playerName) {
    alert("Enter your name!");
    return;
  }
  
  showQuestion();
});

// SHOW QUESTION
function showQuestion() {
  const q = questions[currentQuestion];
  canClick = true;
  timeLeft = 10;
  
  container.innerHTML = `
    <h1>KAMAL QUIZ 🎮</h1>

    <div>
      Question ${currentQuestion + 1} / ${questions.length}
    </div>

    <div style="height:10px;background:#333;border-radius:10px;">
      <div style="height:10px;width:${(currentQuestion/questions.length)*100}%;background:#00ff88;border-radius:10px;"></div>
    </div>

    <h2>${q.question}</h2>

    <div>⏱ Time: <span id="timer">${timeLeft}</span>s</div>

    <div class="answers">
      <button onclick="checkAnswer(0)">${q.answers[0]}</button>
      <button onclick="checkAnswer(1)">${q.answers[1]}</button>
      <button onclick="checkAnswer(2)">${q.answers[2]}</button>
    </div>

    <p>🔥 Streak: ${streak}</p>
  `;
  
  startTimer();
}

// TIMER
function startTimer() {
  clearInterval(timer);
  
  timer = setInterval(() => {
    timeLeft--;
    
    const el = document.getElementById("timer");
    if (el) el.textContent = timeLeft;
    
    if (timeLeft <= 0) {
      clearInterval(timer);
      streak = 0;
      nextQuestion();
    }
  }, 1000);
}

// ANSWER CHECK
window.checkAnswer = function(choice) {
  if (!canClick) return;
  canClick = false;
  
  clearInterval(timer);
  
  const q = questions[currentQuestion];
  const buttons = document.querySelectorAll(".answers button");
  
  buttons.forEach((btn, i) => {
    btn.style.background = i === q.correct ? "#00ff88" : "#ff3b3b";
    btn.style.color = "#000";
  });
  
if (choice === q.correct) {
  score++;
  streak++;
  
  correctSound.currentTime = 0;
  correctSound.play().catch(() => {});
} else {
  streak = 0;
  
  wrongSound.currentTime = 0;
  wrongSound.play().catch(() => {});
}
  
  setTimeout(nextQuestion, 700);
};

// NEXT
function nextQuestion() {
  currentQuestion++;
  
  if (currentQuestion < questions.length) {
    showQuestion();
  } else {
    showResult();
  }
}

// RESULT
function showResult() {
  const rank =
    score >= 25 ? "🔥 LEGEND" :
    score >= 18 ? "🏆 GRANDMASTER" :
    score >= 12 ? "⚔️ PRO" :
    score >= 6 ? "💪 AMATEUR" :
    "🪖 NOOB";
  
  const oldHigh = localStorage.getItem(highScoreKey) || 0;
  
  if (score > oldHigh) {
    localStorage.setItem(highScoreKey, score);
  }
  
  container.innerHTML = `
    <h1>QUIZ COMPLETE 🎮</h1>

    <h2>${playerName}</h2>

    <h3>Score: ${score}/${questions.length}</h3>

    <h2>${rank}</h2>

    <p>🔥 Best Score: ${localStorage.getItem(highScoreKey)}</p>

    <button onclick="location.reload()">Play Again</button>
  `;
}